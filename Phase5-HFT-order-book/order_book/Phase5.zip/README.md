## Building instructions:

mkdir build

cd build

cmake ..

make